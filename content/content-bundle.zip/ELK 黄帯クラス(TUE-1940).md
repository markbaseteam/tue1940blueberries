### Tuesday, March 07, 2023 
### Conversation 

| Word/Phrase |  |
| --------------- | --- |
| wording         | choice of words or phrasing |
| scold           | reprimand, criticize |
| neither A nor B | not A and not B |
| martial arts    | combat sports |
| come in first   | win or finish in first place |
| Can you name one?                | Can you give an example? ||                 |     |

![[Building a Better Future#Building a Better Future 1]]
![[Building a Better Future#Building a Better Future 2]]
### Tuesday, March 14, 2023

暗唱：〜built many apartment buildingsまで
解説：問題の34,35
### Tuesday, March 28, 2023

筆記テスト




暗唱：projectまで
